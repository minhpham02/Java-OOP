package J03022;

/**
 *
 * @author ADMIN
 */
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] tmp;
        String res = "";
        while(in.hasNext()){
            String s = in.next();
            res += s.replaceAll("[.\\!\\?]$", "\n") + " ";
        }
        tmp = res.split("\n\\s?");
        for(String i : tmp){
            System.out.println(i.substring(0, 1).toUpperCase() + i.substring(1).toLowerCase());
        }
    }
}
