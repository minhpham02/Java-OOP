package J04004;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        PhanSo A = new PhanSo(in.nextLong(),in.nextLong());
        PhanSo B = new PhanSo(in.nextLong(),in.nextLong());
        A.add(B);
        System.out.println(A.getTu() + "/" + A.getMau());
    }
}
