package J04004;

/**
 *
 * @author ADMIN
 */
public class PhanSo {
    private long tu, mau;

    public PhanSo(long tu, long mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public long getTu() {
        return tu;
    }

    public long getMau() {
        return mau;
    }
    private long gcd(long a,long b){
        if(b == 0) return a;
        else return gcd(b, a % b);
    }
    
    private void reduceFraction(){
        long GCD = gcd(this.tu,this.mau);
        this.tu /= GCD;
        this.mau /= GCD;
    }
    
    public void add(PhanSo A)
    {
        long LCM = this.mau * A.mau / gcd(this.mau, A.mau);
        this.tu *= LCM / this.mau;
        A.tu *= LCM / A.mau;
        this.mau = LCM;
        this.tu += A.tu;
        this.reduceFraction();
    }
}