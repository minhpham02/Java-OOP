package J04007;

/**
 *
 * @author ADMIN
 */
public class nhanVien {
    private String name, sex, date, address, id, contract;
    public nhanVien(String name, String sex, String date, String address, String id, String contract) {
        this.name = name;
        this.sex = sex;
        this.date = date;
        this.address = address;
        this.id = id;
        this.contract = contract;
    }
    @Override
    public String toString(){
        return "00001 " + name + " " + sex + " " + date + " " + address + " " + id + " " + contract; 
    }
}
