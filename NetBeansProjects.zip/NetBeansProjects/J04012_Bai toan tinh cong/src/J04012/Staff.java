package J04012;

/**
 *
 * @author ADMIN
 */
public class Staff {
    private String id, name, position;
    private long basicSalary, dailySalary, workDays, alloance, bonus;

    public Staff(String name, long dailySalary, long workDays, String position) {
        this.id = "NV01";
        this.name = name;
        this.position = position;
        this.dailySalary = dailySalary;
        this.workDays = workDays;
        basicSalary = workDays * dailySalary;
        if(position.equals("GD"))   alloance = 250000;
        else if(position.equals("PGD"))   alloance = 200000;
        else if(position.equals("TP"))   alloance = 180000;
        else if(position.equals("NV"))   alloance = 150000;
        if(workDays >= 25) bonus = (long) (basicSalary * 0.2);
        else if(workDays < 22) bonus = 0;
        else bonus = (long) (basicSalary * 0.1);
    }
    public long getTotalSalary(){
        return basicSalary + alloance + bonus;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + basicSalary + " " + bonus + " " + alloance + " " + getTotalSalary();
    }
    
}
