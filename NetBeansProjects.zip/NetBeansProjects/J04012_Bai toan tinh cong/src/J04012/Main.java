package J04012;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Staff A = new Staff(in.nextLine(),in.nextLong(),in.nextLong(),in.next());
        System.out.println(A);
    }
}
