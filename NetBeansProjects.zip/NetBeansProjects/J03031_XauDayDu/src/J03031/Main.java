package J03031;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            Set<Character> set = new HashSet<>();
            String s = in.nextLine();
            for(int i = 0;i < s.length();i++){
                set.add(s.charAt(i));
            }
            int k = Integer.parseInt(in.nextLine());
            System.out.println(set.size() + k >= 26 ? "YES" : "NO");
        }
    }
}
