package J05029;

/**
 *
 * @author ADMIN
 */
public class Student implements Comparable<Student>{
    private String idCompany, nameCompany;
    private int amount;

    public Student(String idCompany, String nameCompany, int amount) {
        this.idCompany = idCompany;
        this.nameCompany = nameCompany;
        this.amount = amount;
    }
    
    @Override
    public String toString(){
        return idCompany + " " + nameCompany + " " + amount; 
    }

    public int getAmount() {
        return amount;
    }
    
    @Override
    public int compareTo(Student s){
        if(amount < s.amount)   return 1;
        if(amount > s.amount)   return -1;
        if(idCompany.compareTo(s.nameCompany) > 0)  return 1;
        if(idCompany.compareTo(s.nameCompany) < 0)  return -1;
        return 0;
    }
}
