package J05029;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<Student> st = new ArrayList<>();
        int n = Integer.parseInt(in.nextLine());
        for(int i = 1;i <= n;i++){
            st.add(new Student(in.nextLine(),in.nextLine(),Integer.parseInt(in.nextLine())));
        }
        Collections.sort(st);
        int Q = Integer.parseInt(in.nextLine());
        for(int i = 1;i <= Q;i++){
            String[] s = in.nextLine().split("\\s+");
            int a = Integer.parseInt(s[0]);
            int b = Integer.parseInt(s[1]);
            System.out.println("DANH SACH DOANH NGHIEP NHAN TU " + a + " DEN " + b + " SINH VIEN:");
            for(Student tmp : st){
                if(tmp.getAmount() >= a && tmp.getAmount() <= b)
                    System.out.println(tmp);
            }
        }
    }
}
