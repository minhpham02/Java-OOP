package J04018;

/**
 *
 * @author ADMIN
 */
public class ComplexNumber {
    int real, imaginary;

    public ComplexNumber(int real, int imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    ComplexNumber add (ComplexNumber a) {
        return new ComplexNumber(real + a.real, imaginary + a.imaginary);
    }

    ComplexNumber multiply (ComplexNumber a) {
        return new ComplexNumber(real * a.real - imaginary * a.imaginary, real * a.imaginary + imaginary * a.real);
    }

    @Override
    public String toString() {
        return imaginary >= 0 ? (real + " + " + imaginary + "i") : (real + " - " + Math.abs(imaginary) + "i");
    }
}
