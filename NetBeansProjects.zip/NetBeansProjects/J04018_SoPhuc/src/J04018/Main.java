package J04018;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0) {
            ComplexNumber a = new ComplexNumber(sc.nextInt(), sc.nextInt());
            ComplexNumber b = new ComplexNumber(sc.nextInt(), sc.nextInt());
            ComplexNumber sum = a.add(b);
            System.out.printf("%s, %s\n", sum.multiply(a), sum.multiply(sum));
        }
    }
}
