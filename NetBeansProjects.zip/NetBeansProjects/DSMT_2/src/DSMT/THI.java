package DSMT;


/**
 *
 * @author ADMIN
 */
public class THI implements Comparable<THI>{
    private String code, name, type;

    public THI(String code, String name, String type) {
        this.code = code;
        this.name = name;
        this.type = type;
    }
    
    @Override
    public int compareTo(THI o){
        return this.code.compareTo(o.code);
    }
    
    @Override
    public String toString(){
        return code + " " + name + " " + type;
    }
}
