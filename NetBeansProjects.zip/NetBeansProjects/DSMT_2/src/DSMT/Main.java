package DSMT;

/**
 *
 * @author ADMIN
 */
import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(new File("MONTHI.in"));
        TreeSet<THI> th = new TreeSet<>();
        while(in.hasNext()){
            th.add(new THI(in.nextLine(),in.nextLine(),in.nextLine()));
        }
        for(THI i : th){
            System.out.println(i);
        }
    }
}
