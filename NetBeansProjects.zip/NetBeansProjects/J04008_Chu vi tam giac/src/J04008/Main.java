package J04008;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
        
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        while(t-- > 0){
            Triangle Tri = new Triangle(in.nextDouble(),in.nextDouble(),in.nextDouble(),in.nextDouble(),in.nextDouble(),in.nextDouble());
            System.out.println(Tri);
        }
    }
}
