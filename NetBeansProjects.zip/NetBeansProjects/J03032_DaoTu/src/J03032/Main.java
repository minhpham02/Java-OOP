package J03032;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String[] s = in.nextLine().split(" ");
            for(int i = 0; i < s.length; i++){
                s[i] = new StringBuilder(s[i]).reverse().toString();
            }
            for(String i : s){
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}
