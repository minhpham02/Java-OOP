package J04019;

/**
 *
 * @author ADMIN
 */
public class Triangle {
    Point a, b, c;   
    double ab, ac, bc;
    public Triangle(Point a, Point b, Point c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
  
    public boolean valid(){
        double ab = Math.sqrt((a.getX()-b.getX()) * (a.getX()-b.getX()) + (a.getY()-b.getY()) * (a.getY()-b.getY()));
        double ac = Math.sqrt((a.getX()-c.getX()) * (a.getX()-c.getX()) + (a.getY()-c.getY()) * (a.getY()-c.getY()));
        double bc = Math.sqrt((c.getX()-b.getX()) * (c.getX()-b.getX()) + (c.getY()-b.getY()) * (c.getY()-b.getY()));
        return(ab + ac > bc && ab + bc > ac && ac + bc > ab);
    }
    
    public String getPerimeter(){
        double ab = Math.sqrt((a.getX()-b.getX()) * (a.getX()-b.getX()) + (a.getY()-b.getY()) * (a.getY()-b.getY()));
        double ac = Math.sqrt((a.getX()-c.getX()) * (a.getX()-c.getX()) + (a.getY()-c.getY()) * (a.getY()-c.getY()));
        double bc = Math.sqrt((c.getX()-b.getX()) * (c.getX()-b.getX()) + (c.getY()-b.getY()) * (c.getY()-b.getY()));
        return String.format("%.3f", ab + bc + ac);
    }
}
