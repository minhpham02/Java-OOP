
/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Bai5 {
    public static String check(String s){
        String str = new StringBuffer(s).reverse().toString();
        return s + str;
}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- >0){
            int n = sc.nextInt();
            Queue<String> Q = new LinkedList<>();
            ArrayList<String> list = new ArrayList<>();
            Q.add("");
            String x = Q.poll();
            while(n > 0){
                list.add(check(x + "4"));
                Q.add("4");
                n--;
                if(n > 0){
                    list.add(check(x + "5"));
                    Q.add("5");
                    n--;
                }
                x = Q.poll();
            }
            for(int i = 0;i < list.size();i++){
                System.out.print(list.get(i) + " ");
            }
            System.out.println("\n");
        }
    }
}
    
