package Bai1;

import java.util.Scanner;
import java.util.TreeSet;


/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        TreeSet<Integer> list1 = new TreeSet<>();
        
    }
}
