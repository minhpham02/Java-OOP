package J02037;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String[] tmp = in.nextLine().trim().split("\\s+");
            int n = tmp.length;
            int even = (int) Arrays.asList(tmp).stream().mapToInt(e -> Integer.parseInt(e)).filter(e -> e%2 == 0).count();
            int odd = n - even;
            System.out.println((n % 2 == 0 && even > odd || n % 2 == 1 && odd > even) ? "YES" : "NO");
        }
    }
}
