package J03019;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char[] s = in.nextLine().toCharArray();
        Stack<Character> st = new Stack<>();
        for(char i : s){
            while(!st.empty() && i > st.peek()){
                st.pop();
            }
            st.push(i);
        }
        System.out.println(st.toString().replaceAll("\\[|\\]|\\,\\s+", "")); 
    }
}
