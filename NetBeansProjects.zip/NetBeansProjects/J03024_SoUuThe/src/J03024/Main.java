package J03024;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static  boolean isValid(String s){
        int odd = 0, even = 0;
        for(String i : s.split("")){
            if(i.matches("[02468]"))    even++;
            else odd++;
        }
        return(s.length() % 2 == 0 && even > odd || s.length() % 2 != 0 && even < odd);
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String s = in.next();
            if(s.matches("^0.*") || !s.matches("\\d+"))
                System.out.println("INVALID");
            else
                System.out.println(isValid(s) ? "YES" : "NO");
        }
    }
}
