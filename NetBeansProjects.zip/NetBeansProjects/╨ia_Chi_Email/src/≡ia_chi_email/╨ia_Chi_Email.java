package đia_chi_email;

/**
 *
 * @author ADMIN
 */
import java.util.*;
import java.io.*;

public class Đia_Chi_Email {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(new FileInputStream("DANHSACH.in"));
        ArrayList<String> st = new ArrayList<>();
        int n = Integer.parseInt(in.nextLine());
        for(int i = 1;i <= n;i++){
            String[] tmp = in.nextLine().toLowerCase().trim().split("\\s+");
            String res = tmp[tmp.length - 1];
            for(int j = 0;j < tmp.length - 1;j++){
                res += tmp[j].charAt(0);
            }
            st.add(res);
            int d = Collections.frequency(st, res);
            if(d > 1)
                res += d;
            System.out.println(res + "@ptit.edu.vn");
        }
    } 
}
