package J04003;

/**
 *
 * @author ADMIN
 */
import java.math.BigInteger;

public class phanSo {
    private BigInteger tu, mau;

    public phanSo(BigInteger tu, BigInteger mau) {
        this.tu = tu;
        this.mau = mau;
    }
    @Override
    public String toString(){
        BigInteger gcd = tu.gcd(mau);
        tu = tu.divide(gcd);
        mau = mau.divide(gcd);
        return tu + "/" + mau;
    }
}
