
/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            HashSet<String> h1 = new HashSet<>(Arrays.asList(in.nextLine().split(" ")));
            HashSet<String> h2 = new HashSet<>(Arrays.asList(in.nextLine().split(" ")));
            for(String i : h1){
                if(!h2.contains(i))
                    System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}
