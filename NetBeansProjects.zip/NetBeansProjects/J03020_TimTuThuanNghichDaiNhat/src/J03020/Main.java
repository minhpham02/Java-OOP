package J03020;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map<String,Integer> map = new LinkedHashMap<>();
        int max = 0;
        while(sc.hasNext()){
            String s = sc.next();
            if(check(s)){
                if(!map.containsKey(s)) map.put(s, 1);
                else    map.put(s, map.get(s) + 1);
                max  = Math.max(max, s.length());
            }
        }
        for(String i : map.keySet()){
            if(max == i.length()){
                System.out.println(i + " " + map.get(i));
            }
        }
    }
    public static boolean check(String s){
        StringBuffer sb = new StringBuffer(s);
        String res = sb.reverse().toString();
        if(res.equals(s))   return true;
        return false;
    } 
}
