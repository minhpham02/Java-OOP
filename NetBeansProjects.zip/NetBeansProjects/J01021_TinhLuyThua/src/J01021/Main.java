package J01021;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    private static long Mod = (long) (1e9 + 7);
    static int powMod(long a, long b){
        if(b == 0)  return 1;
        long x = powMod(a, b/2);
        if(b % 2 == 0)  return (int) (x * x % Mod);
        else return (int) (a * (x * x % Mod) % Mod); 
    }
    
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while(true){
            long a = in.nextLong();
            long b = in.nextLong();
            if(a == 0 && b == 0) 
                break;
            else
                System.out.println(powMod(a,b));
        }
    }
}
