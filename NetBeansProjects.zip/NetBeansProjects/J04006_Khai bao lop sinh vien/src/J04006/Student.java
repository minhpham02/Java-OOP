package J04006;

import java.util.*;
import java.text.*;

/**
 *
 * @author ADMIN
 */
class Student{
    private String name, clas, dob;
    private float gpa;

    public Student(String name, String clas, String dob, float gpa) throws ParseException{
        this.name = name;
        this.clas = clas;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
        this.dob = sdf.format(sdf.parse(dob));        
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "B20DCCN001 " + name + " " + clas + " " + dob + " " + String.format("%.2f",gpa) ;
    }   
}
