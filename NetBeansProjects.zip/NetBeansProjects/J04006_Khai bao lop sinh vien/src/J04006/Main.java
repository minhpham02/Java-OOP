package J04006;

/**
 *
 * @author ADMIN
 */
import java.text.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner in = new Scanner(System.in);
        Student A = new Student(in.nextLine(),in.next(),in.next(),in.nextFloat());
        System.out.println(A);
    }
}
