package J02009;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        ArrayList<Pair<Integer,Integer>> map = new ArrayList<>();
        int res = 0;
        while(t-- > 0 ){
            map.add(new Pair<Integer, Integer>(in.nextInt(),in.nextInt()));
        }
        map.sort((a,b) -> a.getFirst().compareTo(b.getFirst()));
        for(Pair<Integer, Integer> tmp : map){
            res = tmp.getFirst() > res ? tmp.getFirst() : res;
            res += tmp.getSecond();
        }
        System.out.println(res);
    }
}
