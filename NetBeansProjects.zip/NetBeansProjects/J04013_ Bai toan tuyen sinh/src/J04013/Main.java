package J04013;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Student S = new Student(in.nextLine(), in.nextLine(),in.nextDouble(), in.nextDouble(), in.nextDouble());
        System.out.println(S);
    }
}
