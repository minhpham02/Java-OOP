package TH;

/**
 *
 * @author ADMIN
 */
public class Team {
    private String id, name, scho;

    public Team(int n, String name, String scho) {
        id = "Team" + String.format("%02d", n);
        this.name = name;
        this.scho = scho;
    }

    public String getId() {
        return id;
    }
    @Override
    public String toString(){
        return name + " " + scho;
    }
}
