package TH;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        ArrayList<Team> te = new ArrayList<>();
        ArrayList<Student> st = new ArrayList<>();
        for(int i = 1;i <= n;i++){
            .add(new Team(i,in.nextLine(),in.nextLine()));
        }
        int m = in.nextInt();
        for(int i = 1;i <= m;i++){
            st.add(new Student(i,in.nextLine(),in.nextLine()));
        }
        Collections.sort(st);
        for(Student tmp : st){
            System.out.println(tmp);
        }
        
    }
}
