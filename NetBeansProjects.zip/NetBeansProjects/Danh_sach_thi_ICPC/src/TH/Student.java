package TH;

/**
 *
 * @author ADMIN
 */
public class Student implements Comparable<Student>{
    private String id,name, team;

    public Student(int n,String name, String team) {
        id = "C" + String.format("%03d", n);
        this.name = name;
        this.team = team;
    }
    @Override
    public String toString(){
        return id + " " + name;
    }

    public Student(String id) {
        this.id = id;
    }
    
    @Override
    public int compareTo(Student s){
        if(name.compareTo(s.name) > 0)  return 1;
        if(name.compareTo(s.name) < 0)  return -1;
        return 0;
    }
}
