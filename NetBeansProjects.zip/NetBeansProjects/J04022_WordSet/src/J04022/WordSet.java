package J04022;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class WordSet {
    TreeSet<String>Set;
    String[] s;

    public WordSet(TreeSet<String> Set) {
        this.Set = Set;
    }
    
    public WordSet(String input){
        this.s = input.toLowerCase().trim().split("\\s+");
        this.Set = new TreeSet<>();
        for(String i : this.s)
            this.Set.add(i);
    }
    public String union(WordSet a){
        TreeSet<String>union = new TreeSet<>(Set);
        for(String i : a.Set)
            union.add(i);
        return String.join(" ", union);
    }
    public String intersection(WordSet a){
        TreeSet<String>inter = new TreeSet<>();
        for(String i : s)
            if(a.Set.contains(i))
                inter.add(i);
        return String.join(" ", inter);
    }
    
}
