package J03018;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String s = in.nextLine();
            s = s.length() > 2 ? s.substring(s.length() - 2) : s;
            int n = Integer.parseInt(s);
            System.out.println(n%4==0 ? 4 : 0);
        }
    }
}
