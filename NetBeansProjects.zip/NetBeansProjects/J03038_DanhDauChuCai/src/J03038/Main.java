package J03038;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char[] s = in.next().toCharArray();
        HashSet<Character> hs = new HashSet<>();
        for(char i : s)
            hs.add(i);
        System.out.println(hs.size());
    }
}
