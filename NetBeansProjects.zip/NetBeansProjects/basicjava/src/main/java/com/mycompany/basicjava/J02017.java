package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
import java.util.ArrayList;

public class J02017 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<Integer> a = new ArrayList<>();
        for(int i = 0 ;i < n;i++){
            a.add(sc.nextInt());
        }
        boolean check = true;
        while(check){
            check = false;
            for(int i = 0;i < a.size() - 1;i++){
                if((a.get(i)+a.get(i+1)) % 2 == 0){
                    a.remove(i);
                    a.remove(i);
                    check = true;
                }
            }
        }
            System.out.print(a.size());
    }
}
