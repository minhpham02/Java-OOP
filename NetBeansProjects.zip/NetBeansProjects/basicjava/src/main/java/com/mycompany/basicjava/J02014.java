package com.mycompany.basicjava;

import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class J02014 {
    static Scanner sc = new Scanner(System.in);
    static void solve(){
        int n = sc.nextInt();
            int[] a = new int[n+5];
            int left = 0, right = 0;
            for(int i = 1;i <= n;i++){
                a[i] = sc.nextInt();
                right += a[i];
            }
            for(int i = 1;i <= n;i++){
                right -= a[i];
                left += a[i-1];
                if(left ==  right){
                    System.out.println(i);
                    return;    
                }
            }
            System.out.println("-1");
        } 
    public static void main(String[] args) {
        int t  = sc.nextInt();
        while(t-- > 0){
            solve();
        }
    }
}
