package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class J02103 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for(int k = 1;k <= t;k++){
            int n = sc.nextInt();
            int m = sc.nextInt();
            int[][] a = new int[n+1][m+1];
            int[][] c = new int[n+1][n+1];
            for(int i = 1;i <= n;i++)
                for(int j = 1;j <= m;j++)
                    a[i][j] = sc.nextInt();
            System.out.printf("Test %d:\n",k);
            for(int i = 1;i <= n;i++){
                for(int j = 1;j <= n;j++){
                    c[i][j] = 0;
                    for(int h = 1;h <= m;h++){
                        c[i][j] += a[i][h] * a[j][h];
                    }
                }
            }
            for(int i = 1;i <= n;i++){
                for(int j = 1;j <= n;j++){
                    System.out.print(c[i][j] + " ");
                }
                System.out.println();
            }
        }
    }
}