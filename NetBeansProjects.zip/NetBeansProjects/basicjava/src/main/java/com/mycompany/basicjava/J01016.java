/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class J01016 {
     public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        long n = sc.nextLong();
        int s = 0;
        while(n > 0){
            long a = n % 10;
            if(a == 4 || a == 7)    s += 1;
            n = n / 10;
        }
        if(s == 4 || s == 7)    System.out.println("YES");
        else System.out.println("NO");
     }
}
