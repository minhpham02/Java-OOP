/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileInputStream;

public class HELLOFILE {
    public static void main(String[] args) throws FileNotFoundException {
        String file = "Hello.txt";
        try(Scanner sc = new Scanner(new FileInputStream(file))){
            while(sc.hasNextLine())
                System.out.println(sc.nextLine());
        }
    }
}
