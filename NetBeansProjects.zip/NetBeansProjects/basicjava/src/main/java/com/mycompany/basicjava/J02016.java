package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
public class J02016 {
    
}
