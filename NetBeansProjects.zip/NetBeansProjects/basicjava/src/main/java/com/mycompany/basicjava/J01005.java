/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class J01005 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0){
            int N = sc.nextInt();
            int H = sc.nextInt();
            double K;
            for(int i = 1; i < N; i++){
                K = H * Math.sqrt((double)i/N);
                System.out.printf("%.6f ", K);
            }
            System.out.print("\n");
        }
            
    }
}
