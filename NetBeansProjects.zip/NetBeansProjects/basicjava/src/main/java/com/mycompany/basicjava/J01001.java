
package com.mycompany.basicjava;

import java.util.Scanner;

public class J01001 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int a, b;
        long S, P;
        a = sc.nextInt();
        b = sc.nextInt();
        if(a <= 0 || b <= 0 )   System.out.println("0");
        else{
            P = (a + b)*2;
            S = a * b;
            System.out.println(P + " " + S);
        }
    }
}   

