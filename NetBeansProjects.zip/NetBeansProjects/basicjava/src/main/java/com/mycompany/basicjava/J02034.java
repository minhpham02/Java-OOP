/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class J02034 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[205];
        int[] m = new int[205];
        int numberMax = 0;
        for(int i = 0 ;i < n ;i++){
            a[i] = sc.nextInt();
            m[a[i]] = 1;
            numberMax = Integer.max(numberMax,a[i]);
        }
        int kt = 1;
        for(int i = 1 ;i <= numberMax ;i++){
            if(m[i] == 0){
                System.out.println(i);
                kt = 0;
            }   
        }
        if(kt == 1) System.out.println("Excellent!");
    }
}
