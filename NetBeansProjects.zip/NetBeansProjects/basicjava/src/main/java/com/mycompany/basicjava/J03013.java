/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.*;
import java.math.BigInteger;

public class J03013 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0){
            String a = sc.next();
            String b = sc.next();
            BigInteger A = new BigInteger(a);
            BigInteger B = new BigInteger(b);
            int length = Math.max(A.toString().length(), B.toString().length());
            System.out.println(String.format("%" + length + "s", A.subtract(B).abs().toString()).replace(' ', '0'));
        }
    }
}
