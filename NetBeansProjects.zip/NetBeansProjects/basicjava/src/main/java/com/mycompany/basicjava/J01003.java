/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class J01003 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        float a, b, c;
        a = sc.nextFloat();
        b = sc.nextFloat();
        if(a == 0 && b != 0)    System.out.printf("VN");
        else if(a == 0 && b == 0)   System.out.printf("VSN");
        else{
            c = (float)-b/(float)a;
            System.out.printf("%.2f", c);
        }
    }
}
