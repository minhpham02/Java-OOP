package com.mycompany.basicjava;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class J02021 {
    static int a[], n, k, d = 0;
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        k = sc.nextInt();
        a = new int[k+5];
        Try(1);
        System.out.format("\nTong cong co %d to hop", d);
    }
    public static void Try(int i){
        int j;
        for(j = a[i-1] + 1;j <= n-k+i;j++){
            a[i] = j;
            if(i == k) out();
            else Try(i+1);
        }   
    }
    public static void out(){
        d++;
        for(int i = 1;i <= k;i++){
            System.out.print(a[i]);
        }
        System.out.print(" ");
    }
}
