package com.mycompany.basicjava;

import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class J03014 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
            BigInteger A = new BigInteger(sc.next());
            BigInteger B = new BigInteger(sc.next());
            BigInteger C = A.add(B);
            System.out.println(C);
    }
}
