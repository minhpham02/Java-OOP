/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class J01008 {
     public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t  = sc.nextInt();
        for(int j = 1;j <= t;j++){
            int n = sc.nextInt();
            int i = 2;
            System.out.print("Test " + j + ": ");       
            while(i <= Math.sqrt(n)){
                if(n % i ==0){
                    int cnt = 0;
                    while(n % i == 0){
                        n = n / i;
                        ++cnt;
                    }
                System.out.print(i + "(" + cnt + ") ");
                }
                i++;
            }
            if(n > 1) System.out.print(n + "(1)");
            System.out.println("");
        }
     }
}
