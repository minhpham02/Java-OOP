/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.*;


public class J02005 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), m = sc.nextInt();
        int[] a = new int[n];
        int[] b = new int[m];
        int[] f1 = new int[1005];
        int[] f2 = new int[1005];
        for(int i = 0;i < 1005;i++){
            f1[i] = f2[i] = 0;
        }
        for(int i = 0;i < n;i++){
            a[i] = sc.nextInt();
            f1[a[i]]++;
        }
        for(int i = 0;i < m;i++){
            b[i] = sc.nextInt();
            f2[b[i]]++;
        }
        for(int i = 0;i <= 1000;i++){
            if(f1[i] == 1 && f2[i] == 1)   System.out.print(i + " ");
        }
    }
}