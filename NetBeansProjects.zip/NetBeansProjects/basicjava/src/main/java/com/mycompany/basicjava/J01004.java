/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class J01004 {
    static boolean check(long n){
        for(int i = 3; i*i <= n; i+=2){
            if(n % i == 0)  return false;
        }
        return true;
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0){
            long n = sc.nextLong();
            if(check(n))    System.out.println("YES");
            else System.out.println("NO");
        }
    }
}
