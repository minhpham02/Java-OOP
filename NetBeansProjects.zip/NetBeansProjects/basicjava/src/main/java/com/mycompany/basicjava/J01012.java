/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class J01012 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0){
            int n = sc.nextInt();
            int count = 0;
            if(n == 2){  System.out.println("1");    continue;
        }
            for(int i = 2 ;i <= Math.sqrt(n);i++){
                int d = 1;
                while(n % 2 == 0){
                    n /= 2;
                    count++;
                }
                while(n % i == 0){
                    n /= i;
                    d++;
                }
            count = count * d;
            }
            if(n > 1) count *= 2;
            System.out.println(count);
        }
    }
}
