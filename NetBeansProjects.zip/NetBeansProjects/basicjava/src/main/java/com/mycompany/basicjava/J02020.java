/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class J02020 {
    static int a[], n, k, d = 0;
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        k = sc.nextInt();
        a = new int[k+5];
        Try(1);
        System.out.format("Tong cong co %d to hop", d);
    }
    public static void Try(int i){
        int j;
        for(j = a[i-1] + 1;j <= n-k+i;j++){
            a[i] = j;
            if(i == k) out();
            else Try(i+1);
        }   
    }
    public static void out(){
        d++;
        for(int i = 1;i <= k;i++){
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }
}
