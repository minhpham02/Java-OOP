package com.mycompany.basicjava;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class J02012 {
    static void Out(ArrayList<Integer> a, int i){
        System.out.printf("Buoc %d: ", i);
        for(int j : a){
            System.out.print(j + " ");
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<Integer> a = new ArrayList<>();
        ArrayList<Integer> b = new ArrayList<>();
        for(int i = 0;i < n;i++){
            a.add(sc.nextInt());
        }
        
        for(int i = 0;i < n;i++){
            b.add(a.get(i)); 
            Collections.sort(b);
            Out(b,i);
            System.out.println();
        }
    }
}
