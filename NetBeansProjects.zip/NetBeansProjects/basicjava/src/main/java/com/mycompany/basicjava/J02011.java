package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class J02011 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<Integer> a = new ArrayList<>();
        for(int i = 0;i < n;i++){
            a.add(sc.nextInt());
        }
        for(int i = 0;i < n - 1;i++){
            int index = i;
            for(int j = i + 1;j < n;j++)
                if(a.get(index) > a.get(j))
                    index = j;
            Collections.swap(a,index,i);    
            System.out.format("Buoc %d:",i+1);
            for(int k = 0;k < n;k++){
                System.out.print(" " + a.get(k));
            }
            System.out.println();
        }
    }
}
