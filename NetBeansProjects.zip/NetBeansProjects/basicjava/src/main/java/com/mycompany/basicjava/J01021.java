/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class J01021 {
    static int mod = (int)1e9+7;
    static long powMod(long a,long b){
        if(b == 0)  return 1;
        long x = powMod(a,b/2);
        if(b % 2 == 0)  return x * x % mod;
        else return a * (x * x % mod) % mod;
    }
    public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    while(true){
        long a = sc.nextLong();
        long b = sc.nextLong();
        if(a == 0 && b == 0)    break;
        else{
            System.out.println(powMod(a,b));
            }
        }
    }
}
