package com.mycompany.basicjava;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class J02013 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<Integer> a = new ArrayList<>();
        for(int i = 0;i < n;i++){
            a.add(sc.nextInt());
        }
        for(int i = 0;i < n;i++){
            boolean check = false;
            for(int j = 0;j < n - i - 1;j++){
                if(a.get(j) > a.get(j+1)){
                    Collections.swap(a, j+1, j);
                    check = true;
                }
            }
            if(check == true){
                System.out.printf("Buoc %d: ",i + 1);
                for(int k : a){
                    System.out.print(k + " ");
                }
            }    
            System.out.println();
        }
    }
}
