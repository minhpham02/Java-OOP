/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.basicjava;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class J02007 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t  = sc.nextInt();
        for(int i = 1;i <= t;i++){
            int n = sc.nextInt();
            int[] a = new int[n];
            int[] f = new int[100005];
            for(int j = 0;j < n; j++){
                a[j] = sc.nextInt();
                f[a[j]]++;
            }
            System.out.println("Test " + i + ":\n");
            for(int j = 0;j < n; j++){
                if(f[a[j]] != -1){
                    System.out.println(a[j] + " xuat hien " + f[a[j]] + " lan");
                    f[a[j]] = -1;
                }
            }
        }
    }
}
