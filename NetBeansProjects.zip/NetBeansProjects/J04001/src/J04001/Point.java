package J04001;

/**
 *
 * @author ADMIN
 */
public class Point {
    
}
