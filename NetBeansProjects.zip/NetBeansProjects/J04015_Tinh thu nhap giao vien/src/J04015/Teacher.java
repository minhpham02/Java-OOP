package J04015;

/**
 *
 * @author ADMIN
 */
public class Teacher {
    private String name, id;
    private int salary;

    public Teacher(String id, String name, int salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }
    public int getAllowance(){
        String pos = id.substring(0, 2);
        switch(pos){
            case "HT":
                return 2000000;
            case "HP":
                return 900000;
            default:
                return 500000;
        }
    }
    public int getCoefficient(){
        return Integer.parseInt(id.substring(2, 4));
    }
    public int getTotalSalary(){
        return getCoefficient() * salary + getAllowance();
    }
    @Override
    public String toString() {
        return id + " " + name + " " + getCoefficient() + " " + getAllowance() + " " + getTotalSalary()  ;
    }
}
