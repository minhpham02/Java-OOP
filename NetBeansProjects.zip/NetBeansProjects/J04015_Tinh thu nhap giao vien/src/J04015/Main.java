package J04015;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Teacher A = new Teacher(in.nextLine(),in.nextLine(),Integer.parseInt(in.nextLine()));
        System.out.println(A);
    }
}
