package j04005;

/**
 *
 * @author ADMIN
 */
public class ThiSinh {
    private String name, date;
    private float   d1, d2, d3, d;
    public ThiSinh(String name, String date, float d1, float d2, float d3) {
        this.name = name;
        this.date = date;
        this.d1 = d1;
        this.d2 = d2;
        this.d3 = d3;
        this.d = d1+d2+d3;
    }
    @Override
    public String toString(){
        return name + " " + date + " " + d; 
    }
}
