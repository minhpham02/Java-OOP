package J03024;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static boolean isReversible(String s){
        int n = s.length(); int diff = 0;
        for(int i = 0; i < n/2; i++){
            if(s.charAt(i) != s.charAt(n - i - 1))
                diff++;
        }
        return (diff == 1 && n % 2 == 0 || diff <= 1 && n % 2 != 0);
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String s = in.next();
            System.out.println(isReversible(s) ? "YES" : "NO");
        }
    }
}
