package J03026;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in  = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String a = in.next();
            String b = in.next();
            System.out.println(a.equals(b) ? "-1" : Math.max(a.length(), b.length()));
        }
    }
}
