package J04002;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        HinhChuNhat A = new HinhChuNhat(in.nextInt(),in.nextInt(),in.nextLine());
        System.out.println(A);
    }
}
