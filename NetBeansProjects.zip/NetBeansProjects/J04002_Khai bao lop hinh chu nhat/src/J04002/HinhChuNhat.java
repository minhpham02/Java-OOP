package J04002;

/**
 *
 * @author ADMIN
 */
public class HinhChuNhat {
    private int width, height; 
    private String color;

    public HinhChuNhat(int width, int height, String color) {
        this.width = width;
        this.height = height;
        this.color = color;
    }
    private int finalArea(){
        return this.width * this.height;
    }
    private int finalPerimeter(){
        return (this.width + this.height) * 2;
    }
    private String getColor(){
        return this.color.substring(1, 2).toUpperCase() + this.color.substring(2).toLowerCase();
    }
    @Override
    public String toString(){
        if (height <= 0 || width <= 0)  return "INVALID";
        else
            return finalPerimeter() + " " + finalArea() + " " + getColor(); 
    }
}
