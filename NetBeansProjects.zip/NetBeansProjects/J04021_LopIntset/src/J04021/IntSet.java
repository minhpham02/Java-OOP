package J04021;

import java.util.TreeSet;

/**
 *
 * @author ADMIN
 */
public class IntSet {
    TreeSet<Integer> set;
    int arr[];

    public IntSet(TreeSet<Integer> s) {
        this.set = new TreeSet<>(s);
    }

    public IntSet(int[] arr) {
        this.arr = arr;
        this.set = new TreeSet<>();
        for(int i : arr)
            this.set.add(i);
    }
    
    public IntSet union(IntSet a){
        TreeSet<Integer> tmp = new TreeSet<>(set);
        tmp.addAll(a.set);
        return new IntSet(tmp);
    }
    
    @Override
    public String toString(){
        TreeSet<String> strs = new TreeSet<>();
        set.forEach(Number -> strs.add(Number.toString()));
        return String.join(" ", strs);
    }
}
