package J03004;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        while(t-- > 0){
            String s = in.nextLine();
            String[] tmp  = s.trim().split("\\s+");
            String res = "";
            for(int i = 1;i < tmp.length;i++){
                res += tmp[i].substring(0, 1).toUpperCase() + tmp[i].substring(1).toLowerCase();
                if(i == tmp.length-1) res += ",";
                else res += " ";
            }
            res += " " + tmp[0].toUpperCase();
            System.out.println(res);
        }    
    }
}
