package J05035;

/**
 *
 * @author ADMIN
 */
public class Student implements Comparable<Student>{
    private String code, name, clas, email, com;
    private int id;

    public Student(int n, String code, String name, String clas, String email, String com) {
        this.id = n;
        this.code = code;
        this.name = name;
        this.clas = clas;
        this.email = email;
        this.com = com;
    }
    
    public int compareTo(Student s){
        return code.compareTo(s.code);
    }

    public String getCom() {
        return com;
    }
    
    @Override
    public String toString(){
        return id + " " + code + " " + name + " " + clas + " " + email + " " + com;
    }
}
