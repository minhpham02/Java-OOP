package J05035;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        ArrayList<Student> st = new ArrayList<>();
        for(int i = 1;i <= n; i++){
            st.add(new Student(i,in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine()));
        }
        Collections.sort(st);
        int Q = Integer.parseInt(in.nextLine());
        for(int i = 1;i <= Q; i++){
            String Company = in.nextLine();
            for(Student tmp : st){
                if(tmp.getCom().equals(Company))
                    System.out.println(tmp);
            }
        }
    }
}
