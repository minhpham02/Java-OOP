package J02020;

/**
 *
 * @author ADMIN
 */
import java.util.*;

public class Main {
    static int n, k, a[];
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        k = in.nextInt();
        a = new int[n+5];
        Try(1);
    }
    
    public static void Try(int i){
        for(int j = a[i-1] + 1; j <= n - k + i;j++){
            a[i] = j;
            if(i == k)  Out();
            else  Try(i+1);
        }
    }
    
    public static void Out(){
        for(int i = 1;i <= k;i++){
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }
}
